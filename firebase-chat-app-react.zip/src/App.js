import React, { useState, useEffect } from "react";
import Login from "./components/Login";
import Chat from "./components/Chat";
import UserList from "./components/UserList";
import { db } from "./firebase";
import { doc, setDoc } from "firebase/firestore";

export default function App() {
  const [username, setUsername] = useState(localStorage.getItem("username"));
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => {
    if (username) {
      setDoc(doc(db, "users", username), {});
    }
  }, [username]);

  if (!username) {
    return <Login onLogin={setUsername} />;
  }

  return (
    <div>
      <h2>Welcome, {username}</h2>
      {!selectedUser ? (
        <UserList currentUser={username} onSelectUser={setSelectedUser} />
      ) : (
        <Chat currentUser={username} selectedUser={selectedUser} />
      )}
    </div>
  );
}
