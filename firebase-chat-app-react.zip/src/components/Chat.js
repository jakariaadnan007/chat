import React, { useEffect, useState } from "react";
import {
  collection,
  addDoc,
  onSnapshot,
  orderBy,
  query,
} from "firebase/firestore";
import { db } from "../firebase";
import { encryptMessage, decryptMessage } from "../utils/encryption";

export default function Chat({ currentUser, selectedUser }) {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");

  const chatId = [currentUser, selectedUser].sort().join("_");

  useEffect(() => {
    const q = query(
      collection(db, "chats", chatId, "messages"),
      orderBy("timestamp")
    );
    const unsubscribe = onSnapshot(q, snapshot => {
      setMessages(snapshot.docs.map(doc => ({
        ...doc.data(),
        id: doc.id,
      })));
    });

    return () => unsubscribe();
  }, [chatId]);

  const sendMessage = async () => {
    if (text.trim()) {
      await addDoc(collection(db, "chats", chatId, "messages"), {
        sender: currentUser,
        content: encryptMessage(text),
        timestamp: new Date(),
      });
      setText("");
    }
  };

  return (
    <div>
      <h3>Chat with {selectedUser}</h3>
      <div style={{ height: "200px", overflowY: "auto", border: "1px solid #ccc" }}>
        {messages.map(msg => (
          <p key={msg.id}>
            <strong>{msg.sender}:</strong> {decryptMessage(msg.content)}
          </p>
        ))}
      </div>
      <input
        value={text}
        onChange={e => setText(e.target.value)}
        placeholder="Type a message"
      />
      <button onClick={sendMessage}>Send</button>
    </div>
  );
}
