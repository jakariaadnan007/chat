import React, { useEffect, useState } from "react";
import { collection, onSnapshot } from "firebase/firestore";
import { db } from "../firebase";

export default function UserList({ currentUser, onSelectUser }) {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, "users"), snapshot => {
      const list = snapshot.docs
        .map(doc => doc.id)
        .filter(username => username !== currentUser);
      setUsers(list);
    });

    return () => unsubscribe();
  }, []);

  return (
    <div>
      <h4>Available Users</h4>
      <ul>
        {users.map(user => (
          <li key={user} onClick={() => onSelectUser(user)}>{user}</li>
        ))}
      </ul>
    </div>
  );
}
