import React, { useState } from "react";

export default function Login({ onLogin }) {
  const [username, setUsername] = useState("");

  const handleLogin = () => {
    if (username.trim()) {
      localStorage.setItem("username", username);
      onLogin(username);
    }
  };

  return (
    <div>
      <h2>Enter Your Username</h2>
      <input value={username} onChange={e => setUsername(e.target.value)} />
      <button onClick={handleLogin}>Login</button>
    </div>
  );
}
