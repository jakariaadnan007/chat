# Firebase Chat App (React)

This is a simple username-based real-time chat application built with React and Firebase. It includes:

- Username-based login
- Real-time messaging using Firestore
- Simulated end-to-end encryption (AES-based demo)
- User list to initiate 1-on-1 chats

## 🔧 Setup Instructions

1. Clone this repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Add your Firebase configuration in `src/firebase.js`
4. Run the app:
   ```bash
   npm start
   ```

## ⚠️ Note
Encryption is simulated using AES and should **not** be used in production without stronger cryptographic protocols.

